package ocupacaoquartos;

import java.util.Scanner;

public class OcupacaoQuartos {

   
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

     
        boolean[][] quartos = new boolean[4][3];

        // registroquartos ocupados
        while (true) {
            System.out.println("Informe Andar e Quarto:");
            int andar = scanner.nextInt();
            int quarto = scanner.nextInt();
            quartos[andar - 1][quarto - 1] = true; // Marcar o quarto como ocupado

            System.out.println("Deseja informar outra ocupação? (S/N)");
            String resposta = scanner.next();
            if (resposta.equalsIgnoreCase("N")) {
                break;
            }
        }

        // Exibição da ocupação 
        System.out.println("Ocupação do hotel:");
        for (int i = 0; i < quartos.length; i++) {
            System.out.println((i + 1) + "º andar:");
            for (int j = 0; j < quartos[i].length; j++) {
                if (quartos[i][j]) {
                    System.out.println("- quarto " + (j + 1) + " ocupado");
                } else {
                    System.out.println("- quarto " + (j + 1) + " desocupado");
                }
            }
        }

        scanner.close();
    }
}
    
    

