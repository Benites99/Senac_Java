
package calculadorahospedagem;

import java.util.Scanner;

public class CalculadoraHospedagem {

   
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

        // Recebendo o valor padrão da diária
        System.out.println("Digite o valor padrão da diária (em R$):");
        double valorDiaria = scanner.nextDouble();

        scanner.nextLine(); // Consumir a quebra de linha após o próximoDouble()

        // Variáveis para contagem
        int gratuidades = 0;
        int meias = 0;
        double total = 0.0;

        // Recebendo nomes de hóspedes e suas idades até que seja digitado "PARE"
        while (true) {
            System.out.println("Digite o nome do hóspede (ou PARE para encerrar):");
            String nome = scanner.nextLine();

            if (nome.equalsIgnoreCase("PARE")) {
                break;
            }

            System.out.println("Digite a idade do hóspede:");
            int idade = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha após o próximoInt()

            // Calculando o valor da hospedagem com base na idade
            double valorHospedagem = valorDiaria;
            if (idade < 4) {
                System.out.println(nome + " possui gratuidade");
                gratuidades++;
            } else if (idade > 80) {
                valorHospedagem /= 2;
                System.out.println(nome + " paga meia");
                meias++;
            }

            total += valorHospedagem;
        }

        // Exibindo os resultados
        System.out.println("Total de hospedagens: R$" + total + "; " + gratuidades + " gratuidade(s); " + meias + " meia(s)");

        scanner.close();
    }
    
}
