import java.util.Scanner;

public class EventoAuditorio {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o número de convidados do evento:");
        int numConvidados = scanner.nextInt();
        
        System.out.println("Número de convidados inserido: " + numConvidados);

        if (numConvidados <= 0 || numConvidados > 350) {
            System.out.println("Número de convidados inválido");
        } else if (numConvidados <= 150) {
            System.out.println("Use o auditório Alfa");
            int cadeirasAdicionais = Math.min(70, 150 - numConvidados);
            if (cadeirasAdicionais > 0) {
                System.out.println("Inclua mais " + cadeirasAdicionais + " cadeiras");
            } else {
                System.out.println("Não são necessárias cadeiras adicionais");
            }
        } else {
            System.out.println("Use o auditório Beta");
        }

        scanner.close();
    }
}
