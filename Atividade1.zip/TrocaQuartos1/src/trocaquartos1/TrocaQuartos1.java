package trocaquartos1;

import java.util.Scanner;





public class TrocaQuartos1 {

  

    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

        // Recebendo os dados do primeiro hóspede
        System.out.println("Digite o nome do primeiro hóspede:");
        String nome1 = scanner.nextLine();
        System.out.println("Digite a idade do primeiro hóspede:");
        int idade1 = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha após o próximoInt()

        // Definindo o desconto para o primeiro hóspede, se necessário
        double desconto1 = 0.0;
        if (idade1 >= 60) {
            desconto1 = 0.4;
        }

        // Recebendo os dados do segundo hóspede
        System.out.println("Digite o nome do segundo hóspede:");
        String nome2 = scanner.nextLine();
        System.out.println("Digite a idade do segundo hóspede:");
        int idade2 = scanner.nextInt();

        // Definindo o desconto para o segundo hóspede, se necessário
        double desconto2 = 0.0;
        if (idade2 >= 60) {
            desconto2 = 0.4;
        }

        // Trocando os quartos conforme as condições especificadas
        String quartoA, quartoB;
        if (idade2 < idade1) {
            quartoA = nome2;
            quartoB = nome1 + (desconto1 > 0 ? " com desconto de " + (int)(desconto1 * 100) + "%" : "");
        } else {
            quartoA = nome1 + (desconto1 > 0 ? " com desconto de " + (int)(desconto1 * 100) + "%" : "");
            quartoB = nome2 + (desconto2 > 0 ? " com desconto de " + (int)(desconto2 * 100) + "%" : "");
        }

        // Exibindo os resultados
        System.out.println("Quarto A: " + quartoA + "; Quarto B: " + quartoB);

        scanner.close();
    }
    
}
