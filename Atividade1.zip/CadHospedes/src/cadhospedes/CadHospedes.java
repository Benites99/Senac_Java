
package cadhospedes;
import java.util.Scanner;

public class CadHospedes {

  
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

        String[] hospedes = new String[15]; // Array para armazenar os hóspedes
        int contador = 0; // Contador de hóspedes cadastrados

        // Menu principal
        while (true) {
            System.out.println("Digite 1- cadastrar; 2- pesquisar; 3- sair");
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a quebra de linha após o próximoInt()

            if (opcao == 1) {
                if (contador < 15) {
                    System.out.println("Digite o nome do hóspede:");
                    String nome = scanner.nextLine();
                    hospedes[contador] = nome;
                    System.out.println("Hóspede cadastrado com sucesso.");
                    contador++;
                } else {
                    System.out.println("Máximo de cadastros atingido.");
                }
            } else if (opcao == 2) {
                System.out.println("Digite o nome do hóspede a ser pesquisado:");
                String nomePesquisa = scanner.nextLine();
                boolean encontrado = false;
                for (int i = 0; i < contador; i++) {
                    if (hospedes[i].equalsIgnoreCase(nomePesquisa)) {
                        System.out.println("Hóspede " + nomePesquisa + " foi encontrado no índice " + i);
                        encontrado = true;
                        break;
                    }
                }
                if (!encontrado) {
                    System.out.println("Hóspede não encontrado.");
                }
            } else if (opcao == 3) {
                break; // Encerrar o programa
            } else {
                System.out.println("Opção inválida. Por favor, digite 1, 2 ou 3.");
            }
        }

        scanner.close();
    }
    
}
